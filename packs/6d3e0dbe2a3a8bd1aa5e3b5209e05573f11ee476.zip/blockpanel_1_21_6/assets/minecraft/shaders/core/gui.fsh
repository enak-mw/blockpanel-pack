#version 150

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
    float LineWidth;
};

in vec4 vertexColor;
flat in vec4 chatClip;
in vec2 chatAt;

out vec4 fragColor;

bool chatClipped(vec4 box, vec2 at) {
    return box.z > box.x && all(greaterThanEqual(at, box.xy)) && all(lessThanEqual(at, box.zw));
}


void main() {
    if (chatClipped(chatClip, chatAt)) {
        discard;
    }
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
