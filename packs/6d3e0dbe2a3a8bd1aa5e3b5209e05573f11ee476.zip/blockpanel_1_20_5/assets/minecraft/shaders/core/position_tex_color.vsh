#version 150

in vec3 Position;
in vec2 UV0;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;
out vec4 vertexColor;
flat out float panelCursor;
out vec2 cursorPixel;

bool underwaterOverlay() {
    vec3 off = abs(vec3(abs(Position.xy), Position.z) - vec3(1.0, 1.0, -0.5));
    return max(off.x, max(off.y, off.z)) < 0.001 && abs(Color.a - 0.1) < 0.02;
}

void main() {
    panelCursor = 0.0;
    cursorPixel = vec2(0.0);
    if (underwaterOverlay()) {
        vec2 uv = UV0 - 4.0 * step(Position.xy, vec2(0.0));
        vec2 turn = vec2(-64.0 * uv.x - 36000.0, 64.0 * uv.y);
        if (abs(turn.x) < 360.0) {
            float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
            vec2 half_view = vec2(max(1920.0, 1080.0 * aspect), max(1080.0, 1920.0 / aspect)) / 2.0;
            vec2 tip = clamp(turn * vec2(16.0, 12.0), -half_view, half_view);
            vec2 corner = step(vec2(0.0), Position.xy);
            cursorPixel = vec2(corner.x, 1.0 - corner.y) * 32.0;
            vec2 at = (tip + (cursorPixel - 1.0) * 1.5) / half_view;
            vec4 overlay = ProjMat * ModelViewMat * vec4(Position, 1.0);
            float up = sign(overlay.y / overlay.w) == sign(Position.y) ? 1.0 : -1.0;
            gl_Position = vec4(at.x, -at.y * up, 0.0, 1.0);
            texCoord0 = vec2(0.0);
            vertexColor = vec4(1.0);
            panelCursor = 1.0;
            return;
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    vertexColor = Color;
}
