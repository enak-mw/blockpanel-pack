#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};

layout(location = 0) in vec4 vertexColor;
layout(location = 1) flat in vec4 chatClip;
layout(location = 2) in vec2 chatAt;

layout(location = 0) out vec4 fragColor;

bool chatClipped(vec4 box, vec2 at) {
    return box.z > box.x && all(greaterThanEqual(at, box.xy)) && all(lessThanEqual(at, box.zw));
}


void main() {
    if (chatClipped(chatClip, chatAt)) {
        discard;
    }
    vec4 color = vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
