#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;

in vec2 texCoord0;
in vec4 vertexColor;
flat in float panelCursor;
in vec2 cursorPixel;

out vec4 fragColor;

const vec2 ARROW[7] = vec2[7](vec2(1.0, 1.0), vec2(1.0, 18.0), vec2(5.0, 14.0), vec2(8.0, 20.5),
    vec2(10.5, 19.5), vec2(7.5, 13.0), vec2(13.0, 13.0));

float distanceToArrow(vec2 p) {
    float nearest = 1.0e9;
    bool inside = false;
    for (int i = 0, j = 6; i < 7; j = i++) {
        vec2 a = ARROW[i];
        vec2 edge = ARROW[j] - a;
        vec2 from = p - a;
        nearest = min(nearest, length(from - edge * clamp(dot(from, edge) / dot(edge, edge), 0.0, 1.0)));
        if ((a.y > p.y) != (ARROW[j].y > p.y) && p.x < a.x + edge.x * (p.y - a.y) / edge.y) {
            inside = !inside;
        }
    }
    return inside ? -nearest : nearest;
}

void main() {
    if (panelCursor > 0.5) {
        float d = distanceToArrow(cursorPixel);
        float soft = fwidth(cursorPixel.x);
        float alpha = 1.0 - smoothstep(0.5 - soft, 0.5 + soft, d);
        if (alpha <= 0.0) {
            discard;
        }
        vec3 fill = vec3(1.0);
        vec3 outline = vec3(0.0);
        fragColor = vec4(mix(fill, outline, smoothstep(-0.5 - soft, -0.5 + soft, d)), alpha);
        return;
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
