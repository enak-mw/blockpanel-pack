#version 150
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const float NO_FOG = -1.0e6;

bool panelVertex() {
    return ProjMat[3][3] == 0.0 && UV2 == ivec2(240, 224) && dot(Position, Position) < 16.0;
}

vec4 fitPanel(vec4 position) {
    float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
    position.xy *= 1080.0 / (0.70020754 * max(1080.0, 1920.0 / aspect) * abs(ProjMat[1][1]));
    position.z = (position.z + position.w) * 0.05 - position.w;
    return position;
}

bool inventoryLabel() {
    if (ProjMat[3][3] != 1.0 || any(greaterThan(abs(Color.rgb * 255.0 - vec3(64.0)), vec3(0.6)))) {
        return false;
    }
    vec2 screen = ceil(2.0 / abs(vec2(ProjMat[0][0], ProjMat[1][1])) - 0.001);
    vec2 at = Position.xy - floor((screen - vec2(176.0, 166.0)) / 2.0);
    return at.x >= 7.0 && at.x <= 176.0 && at.y >= 71.0 && at.y <= 81.0;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    if (panelVertex()) {
        gl_Position = fitPanel(gl_Position);
        vertexDistance = NO_FOG;
        vertexColor = Color;
    }
    if (inventoryLabel()) {
        vertexColor = vec4(0.0);
    }
}
