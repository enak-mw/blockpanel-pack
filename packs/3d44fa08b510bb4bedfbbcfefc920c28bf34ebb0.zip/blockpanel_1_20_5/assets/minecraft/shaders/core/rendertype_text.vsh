#version 150
#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;
uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

const float NO_FOG = -1.0e6;

bool panelVertex() {
    return ProjMat[3][3] == 0.0 && UV2 == ivec2(240, 224) && dot(Position, Position) < 16.0;
}

vec4 fitPanel(vec4 position) {
    float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
    position.xy *= 1080.0 / (0.70020754 * max(1080.0, 1920.0 / aspect) * abs(ProjMat[1][1]));
    position.z = (position.z + position.w) * 0.05 - position.w;
    return position;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    if (panelVertex()) {
        gl_Position = fitPanel(gl_Position);
        vertexDistance = NO_FOG;
        vertexColor = Color;
    }
}
