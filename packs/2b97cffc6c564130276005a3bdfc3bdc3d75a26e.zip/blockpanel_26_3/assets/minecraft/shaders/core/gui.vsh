#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl, projection.glsl and globals.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;
layout(location = 1) flat out vec4 chatClip;
layout(location = 2) out vec2 chatAt;

const vec4 CHAT_BAR = vec4(100.0, 920.0, 1010.0, 60.0);

float panelSteps() {
    return floor((GameTime * 24000.0 - 21000.0) / 24.0);
}

// How big the panel is on the screen, as a fraction, while it's open and fits itself; otherwise 0.
float panelSize() {
    float steps = panelSteps();
    return steps < 0.0 ? 0.0 : min(0.2 + 0.02 * floor(steps / 3.0), 1.0);
}

// The same, only while chat's line belongs in the bar, and on a screen's shaders.
float chatInBar() {
    return ProjMat[3][3] != 1.0 || mod(panelSteps(), 3.0) < 0.5 ? 0.0 : panelSize();
}

// While chatInBar(): whether the box a click on the bar opened is up, over everything but the HUD.
bool chatAway() {
    return mod(panelSteps(), 3.0) > 1.5;
}

// Where chat's messages can be, at its widest and tallest: 320 wide with 12 of edges, from 40 up from the
// bottom of the screen to 200 above that, and what it shows above its line, down to the line.
bool inChatMessages(vec2 at, vec2 screen) {
    return at.x <= 332.5 && at.y > screen.y - 239.5 && at.y < screen.y - 12.5;
}

vec4 chatMessagesBox(vec2 screen) {
    return vec4(0.0, screen.y - 239.5, 332.5, screen.y - 12.5);
}

vec2 guiScreen() {
    return ceil(2.0 / abs(vec2(ProjMat[0][0], ProjMat[1][1])) - 0.001);
}

// GUI pixels per canvas pixel: the whole canvas shows, its longer side touching the screen's edges.
float canvasScale(vec2 screen, float size) {
    return min(screen.x / 1920.0, screen.y / 1080.0) * size;
}

vec2 canvasPoint(vec2 canvas, vec2 screen, float size) {
    return screen / 2.0 + (canvas - vec2(960.0, 540.0)) * canvasScale(screen, size);
}

// Where a point of chat's line goes. It starts at x = 4, with its text 8 high around height - 6.
vec2 inBar(vec2 at, vec2 screen, float size) {
    vec2 to = canvasPoint(CHAT_BAR.xy + vec2(20.0, CHAT_BAR.w / 2.0), screen, size)
        + (at - vec2(4.0, screen.y - 6.0)) * 3.6 * canvasScale(screen, size);
    to.x = min(to.x, canvasPoint(CHAT_BAR.xy + vec2(CHAT_BAR.z - 20.0, 0.0), screen, size).x);
    return to;
}

// The bar, from its top left to its bottom right: chat's messages aren't drawn there.
vec4 barBox(vec2 screen, float size) {
    return vec4(canvasPoint(CHAT_BAR.xy, screen, size), canvasPoint(CHAT_BAR.xy + CHAT_BAR.zw, screen, size));
}

// The box's button: 200 x 20, 40 up from the bottom, in the middle. Its label is 6 down from its top.
bool inChatButton(vec2 at, vec2 screen) {
    return abs(at.x - floor(screen.x / 2.0)) <= 100.01;
}

bool chatButtonLabel(vec2 at, vec2 screen) {
    return inChatButton(at, screen) && at.y >= screen.y - 35.01 && at.y <= screen.y - 23.99;
}

// Its picture is cut in nine with a border of 3, so its corners are on just these rows.
bool chatButtonPicture(vec2 at, vec2 screen) {
    float y = screen.y - at.y;
    return inChatButton(at, screen) && (abs(y - 40.0) < 0.01 || abs(y - 37.0) < 0.01 || abs(y - 23.0) < 0.01
        || abs(y - 20.0) < 0.01);
}


// Block Panel: the dim is 0xC0101010 to 0xD0101010, and nothing else is.
bool typingDim(vec4 c) {
    vec3 d = abs(c.rgb - vec3(16.0 / 255.0));
    return max(d.r, max(d.g, d.b)) < 0.001 && (abs(c.a - 192.0 / 255.0) < 0.001 || abs(c.a - 208.0 / 255.0) < 0.001);
}

// Block Panel: the fade is 0x101020 at any strength, and nothing else is.
bool sleepFade(vec4 c) {
    vec3 d = abs(c.rgb - vec3(16.0, 16.0, 32.0) / 255.0);
    return max(d.r, max(d.g, d.b)) < 0.001;
}

void main() {
    vec3 at = Position;
    vec4 color = sleepFade(Color) || typingDim(Color) ? vec4(0.0) : Color;
    chatClip = vec4(0.0);
    chatAt = Position.xy;
    float size = chatInBar();
    if (size > 0.0) {
        vec2 screen = guiScreen();
        bool strip = (abs(Position.x - 2.0) < 0.01 || abs(Position.x - screen.x + 2.0) < 0.01)
            && (abs(Position.y - screen.y + 14.0) < 0.01 || abs(Position.y - screen.y + 2.0) < 0.01);
        if (strip) {
            at.xy = canvasPoint(CHAT_BAR.xy + vec2(Position.x < screen.x / 2.0 ? 0.0 : CHAT_BAR.z,
                Position.y < screen.y - 8.0 ? 0.0 : CHAT_BAR.w), screen, size);
            color = vec4(0.04, 0.05, 0.07, 1.0);
        } else if (Position.y >= screen.y - 11.5) {
            // The caret and what's selected: a pixel above the text to a pixel below it.
            at.xy = inBar(Position.xy, screen, size);
        } else {
            // Chat's messages' see-through backgrounds
            chatClip = chatAway() && inChatMessages(Position.xy, screen) ? chatMessagesBox(screen)
                : barBox(screen, size);
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(at, 1.0);

    vertexColor = color;
}
