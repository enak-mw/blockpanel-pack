#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;
flat out vec4 chatClip;
out vec2 chatAt;

bool inventoryLabel() {
    // Text in the world has a perspective: only a screen's, and only in the label's gray.
    if (ProjMat[3][3] != 1.0 || any(greaterThan(abs(Color.rgb * 255.0 - vec3(64.0)), vec3(0.6)))) {
        return false;
    }
    // Where the 176 x 166 frame is, from the size of the screen.
    vec2 screen = ceil(2.0 / abs(vec2(ProjMat[0][0], ProjMat[1][1])) - 0.001);
    vec2 at = Position.xy - floor((screen - vec2(176.0, 166.0)) / 2.0);
    return at.x >= 7.0 && at.x <= 176.0 && at.y >= 71.0 && at.y <= 81.0;
}

// Whether this letter is in a colour chat's typing line has: the box's own light grey, or on the Console tab
// the aqua of the one argument its commands have, each with its shadow, a quarter as bright. A command's
// slash is grey, which a button's label can be too, but the slash is only ever first, 4 in from the left.
bool typedColour() {
    vec3 c = Color.rgb * 255.0;
    return all(lessThan(abs(c - vec3(224.0)), vec3(0.6))) || all(lessThan(abs(c - vec3(56.0)), vec3(0.6)))
        || all(lessThan(abs(c - vec3(85.0, 255.0, 255.0)), vec3(0.6)))
        || all(lessThan(abs(c - vec3(21.0, 63.0, 63.0)), vec3(0.6)))
        || Position.x < 12.5 && (all(lessThan(abs(c - vec3(170.0)), vec3(0.6)))
            || all(lessThan(abs(c - vec3(42.0)), vec3(0.6))));
}

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
const float NO_FOG = -1.0e6;

bool panelVertex() {
    return ProjMat[3][3] == 0.0 && UV2 == ivec2(240, 224) && dot(Position, Position) < 16.0;
}

vec4 fitPanel(vec4 position) {
    float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
    position.xy *= 1080.0 / (0.70020754 * max(1080.0, 1920.0 / aspect) * abs(ProjMat[1][1]));
    position.z = (position.z + position.w) * 0.05 - position.w;
    return position;
}

#endif

const vec4 CHAT_BAR = vec4(100.0, 920.0, 1010.0, 60.0);

float panelSteps() {
    return floor((GameTime * 24000.0 - 21000.0) / 24.0);
}

// How big the panel is on the screen, as a fraction, while it's open and fits itself; otherwise 0.
float panelSize() {
    float steps = panelSteps();
    return steps < 0.0 ? 0.0 : min(0.2 + 0.02 * floor(steps / 3.0), 1.0);
}

// The same, only while chat's line belongs in the bar, and on a screen's shaders.
float chatInBar() {
    return ProjMat[3][3] != 1.0 || mod(panelSteps(), 3.0) < 0.5 ? 0.0 : panelSize();
}

// While chatInBar(): whether the box a click on the bar opened is up, over everything but the HUD.
bool chatAway() {
    return mod(panelSteps(), 3.0) > 1.5;
}

// Where chat's messages can be, at its widest and tallest: 320 wide with 12 of edges, from 40 up from the
// bottom of the screen to 200 above that, and what it shows above its line, down to the line.
bool inChatMessages(vec2 at, vec2 screen) {
    return at.x <= 332.5 && at.y > screen.y - 239.5 && at.y < screen.y - 12.5;
}

vec4 chatMessagesBox(vec2 screen) {
    return vec4(0.0, screen.y - 239.5, 332.5, screen.y - 12.5);
}

vec2 guiScreen() {
    return ceil(2.0 / abs(vec2(ProjMat[0][0], ProjMat[1][1])) - 0.001);
}

// GUI pixels per canvas pixel: the whole canvas shows, its longer side touching the screen's edges.
float canvasScale(vec2 screen, float size) {
    return min(screen.x / 1920.0, screen.y / 1080.0) * size;
}

vec2 canvasPoint(vec2 canvas, vec2 screen, float size) {
    return screen / 2.0 + (canvas - vec2(960.0, 540.0)) * canvasScale(screen, size);
}

// Where a point of chat's line goes. It starts at x = 4, with its text 8 high around height - 6.
vec2 inBar(vec2 at, vec2 screen, float size) {
    vec2 to = canvasPoint(CHAT_BAR.xy + vec2(20.0, CHAT_BAR.w / 2.0), screen, size)
        + (at - vec2(4.0, screen.y - 6.0)) * 3.6 * canvasScale(screen, size);
    to.x = min(to.x, canvasPoint(CHAT_BAR.xy + vec2(CHAT_BAR.z - 20.0, 0.0), screen, size).x);
    return to;
}

// The bar, from its top left to its bottom right: chat's messages aren't drawn there.
vec4 barBox(vec2 screen, float size) {
    return vec4(canvasPoint(CHAT_BAR.xy, screen, size), canvasPoint(CHAT_BAR.xy + CHAT_BAR.zw, screen, size));
}

// The box's button: 200 x 20, 40 up from the bottom, in the middle. Its label is 6 down from its top.
bool inChatButton(vec2 at, vec2 screen) {
    return abs(at.x - floor(screen.x / 2.0)) <= 100.01;
}

bool chatButtonLabel(vec2 at, vec2 screen) {
    return inChatButton(at, screen) && at.y >= screen.y - 35.01 && at.y <= screen.y - 23.99;
}

// Its picture is cut in nine with a border of 3, so its corners are on just these rows.
bool chatButtonPicture(vec2 at, vec2 screen) {
    float y = screen.y - at.y;
    return inChatButton(at, screen) && (abs(y - 40.0) < 0.01 || abs(y - 37.0) < 0.01 || abs(y - 23.0) < 0.01
        || abs(y - 20.0) < 0.01);
}


void main() {
    vec3 at = Position;
    bool hidden = false;
    chatClip = vec4(0.0);
    chatAt = Position.xy;
    float size = chatInBar();
    if (size > 0.0) {
        vec2 screen = guiScreen();
        // Chat's typing line: letters from 12 up from the bottom of the screen, their shadows 1 lower. Other
        // labels reach that low with their bottom corners (a dialog's buttons, in any colour), so only the
        // typing line's colours go.
        if (Position.y >= screen.y - 12.5 && typedColour()) {
            at.xy = inBar(Position.xy, screen, size);
        } else {
            hidden = hidden || chatButtonLabel(Position.xy, screen);
            chatClip = chatAway() && inChatMessages(Position.xy, screen) ? chatMessagesBox(screen)
                : barBox(screen, size);
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(at, 1.0);
    texCoord0 = UV0;

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    if (panelVertex()) {
        gl_Position = fitPanel(gl_Position);
        sphericalVertexDistance = NO_FOG;
        cylindricalVertexDistance = NO_FOG;
        vertexColor = Color;
    }
#else
    vertexColor = Color;
#endif
    if (hidden) {
        vertexColor = vec4(0.0);
    }
}
