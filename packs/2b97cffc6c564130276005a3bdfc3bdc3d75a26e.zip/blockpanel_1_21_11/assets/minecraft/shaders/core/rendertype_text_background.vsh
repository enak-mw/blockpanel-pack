#version 330

#ifndef IS_SEE_THROUGH
#moj_import <minecraft:fog.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
#ifndef IS_SEE_THROUGH
in ivec2 UV2;
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;

#ifndef IS_SEE_THROUGH
const float NO_FOG = -1.0e6;

bool panelVertex() {
    return ProjMat[3][3] == 0.0 && UV2 == ivec2(240, 224) && dot(Position, Position) < 16.0;
}

vec4 fitPanel(vec4 position) {
    float aspect = abs(ProjMat[1][1] / ProjMat[0][0]);
    position.xy *= 1080.0 / (0.70020754 * max(1080.0, 1920.0 / aspect) * abs(ProjMat[1][1]));
    position.z = (position.z + position.w) * 0.05 - position.w;
    return position;
}

#endif

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

#ifndef IS_SEE_THROUGH
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    if (panelVertex()) {
        gl_Position = fitPanel(gl_Position);
        sphericalVertexDistance = NO_FOG;
        cylindricalVertexDistance = NO_FOG;
        vertexColor = Color;
    }
#else
    vertexColor = Color;
#endif
}
